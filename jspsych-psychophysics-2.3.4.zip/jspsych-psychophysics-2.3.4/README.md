# jspsych-psychophysics
This is a jsPsych plugin for psychophysics.
Please refer to the website: https://kurokida.github.io/jspsych-psychophysics/
